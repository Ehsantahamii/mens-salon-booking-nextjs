import Preloader from "@/components/template/Preloader";

export default function Loading() {
  return <Preloader />;
}
