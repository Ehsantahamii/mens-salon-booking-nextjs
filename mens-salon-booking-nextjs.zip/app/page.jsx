import Hero from "@/components/layout/Hero";
import MainPage from "@/components/page/MainPage";
import Image from "next/image";

export default function Home() {
  return (
    <MainPage />
  );
}
