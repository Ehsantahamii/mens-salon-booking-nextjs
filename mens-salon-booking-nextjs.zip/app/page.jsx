import MainPage from "@/components/page/MainPage";

export default function Home() {
  return (
    <MainPage />
  );
}
