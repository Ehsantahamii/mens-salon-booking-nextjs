import Hero from "@/components/layout/Hero";
import Image from "next/image";

export default function Home() {
  return (
    <Hero/>
  );
}
