import React from 'react';

const ReservedListPage = () => {
    return (
        <div>

        </div>
    );
};

export default ReservedListPage;