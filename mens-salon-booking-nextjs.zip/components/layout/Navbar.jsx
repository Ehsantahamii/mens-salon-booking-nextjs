"use client"
const Navbar = () => {
    return (
        <nav className="w-full h-32">

        </nav>
    );
};

export default Navbar;